<?php
        include_once "../factory/conexao.php";

        $email = $_POST["cxemail_edit"];

        $cxnome = $_POST["cxnome"];
        $cxemail = $_POST["cxemail"];
        $cxcontato = $_POST["cxcontato"];
        $cxtel = $_POST["cxtel"];
        $cxsenha = $_POST["cxsenha"];

        $alterar = "UPDATE tbcomercio SET nome = '$cxnome', email = '$cxemail', contato = '$cxcontato', tel = '$cxtel', senha = '$cxsenha' where email = '$email'";

        $executar = mysqli_query($conn,$alterar);
        if ($email !== "") {
            header("location: ../view/tela_login.php");
        }else {
            header("location: ../view/tela_edit_comercio.php");
        }


    ?>