<!DOCTYPE html>
<html lang="pt-bt">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/estilos.css">
    <title>Cadastro</title>
</head>
<body>
    <header id="baner">
        <a href="../view/tela_login.php">home</a><br><br><br>
        <h1 id="logo">Cadastro Amigo</h1>
    </header>
    <section id="cxprincipal">
    <form action="../model/inserir_amigos.php" method="POST"><br><br>
            <input type="text" name="cxnome" placeholder="Nome" require><br><br>
            <input type="text" name="cxemail"placeholder="Email"require><br><br>
            <input type="number" name="cxtel"placeholder="tel"require><br><br>
            <input type="text" name="cxdatanasc" placeholder="data nascimento"require><br><br>
            <input type="text" name="cxsenha" placeholder="Senha"require><br><br>
            <input type="text" name="cxconfirmar" placeholder="Confirmar Senha"require><br><br>
            <input type="submit" value="cadastrar">
        </form>
        <br><hr><br>
        <form action="../model/consulta_amigos_nome.php" method = "POST">
            <form action="">
            <label for="">digite o nome completo do usuario</label><br>  
            <input type="text" name="cxpesquisa"/>
            <input type="submit" value="pesquisa"/>
        </form>

    </section>
    <footer>
    Desenvolvido por &copy Paulo Thomaz Filho 3º info
    </footer>
</body>
</html>
