<!DOCTYPE html>
<html lang="pt-bt">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/estilomenu.css">
    <title>Cadastro</title>
</head>
<body>
    <header id="baner">
        <h1 id="logo">W.D.S</h1>
    </header>
    <section id="cxprincipal">
        <table>
            <tr>
                <td class="cade"><a href="tela_cade_amigo.php"><button><b>Cadastrar/Pesquisar <br>Amigo</button></a></td>
                <td class="cade"><a href="tela_cade_comercio.php"><button><b>Cadastrar/Pesquisar <br>Comercio</button></a></td>
                <td class="cade"><a href="tela_cade_user.php"><button><b>Cadastrar/Pesquisar <br>Usuario</button></a></td>
            </tr>
            <tr>
                <td class="cade f"><a href="tela_edit_amigo.php"><button><b>Editar/Excluir <br>Amigo</button></a></td>
                <td class="cade f"><a href="tela_edit_comercio.php"><button><b>Editar/Excluir <br>Comercio</button></a></td>
                <td class="cade f"><a href="tela_edit_usuario.php"><button><b>Editar/Excluir <br>Usuario</button></a></td>
            </tr>
        </table>
    </section>
    <footer class="c">
    Desenvolvido por &copy Paulo Thomaz Filho 3º info
    </footer>
</body>
</html>