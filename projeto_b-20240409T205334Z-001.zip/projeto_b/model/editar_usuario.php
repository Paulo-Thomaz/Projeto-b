<?php
        include_once "../factory/conexao.php";

        $email = $_POST["cxemail_edit"];

        $cxnome = $_POST["cxnome"];
        $cxemail = $_POST["cxemail"];
        $cxsenha = $_POST["cxsenha"];

        $alterar = "UPDATE tbusuario SET nome = '$cxnome', email = '$cxemail', senha = '$cxsenha' where email = '$email'";

        $executar = mysqli_query($conn,$alterar);
        if ($email !== "") {
            header("location: ../view/tela_login.php");
        }else {
            header("location: ../view/tela_edit_usuario.php");
        }


    ?>