<?php
    if($_POST["cxnome"] != ""){
        include_once "../factory/conexao.php";
        $nome = $_POST["cxnome"];
        $email = $_POST["cxemail"];
        $senha = $_POST["cxsenha"];
        $confirmar = $_POST["cxconfirmar"];
        if ($senha == $confirmar) {
            $sql = "insert into tbusuario(nome,email,senha)values('$nome','$email','$senha')";
            $query = mysqli_query($conn,$sql);
            header("location: ../view/tela_login.php");
        }
    }
    else {
        header("location: ../view/tela_caduse.php");
        echo  "<script>alert('Email enviado com Sucesso!);</script>";
    }
?>