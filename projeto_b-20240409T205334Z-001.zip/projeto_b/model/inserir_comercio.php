<?php
    if($_POST["cxnome"] != "" && $_POST["cxsenha"] != ""){
        include_once "../factory/conexao.php";
        $nome = $_POST["cxnome"];
        $email = $_POST["cxemail"];
        $contato = $_POST["cxcontato"];
        $tel = $_POST["cxtel"];
        $senha = $_POST["cxsenha"];
        $confirmar = $_POST["cxconfirmar"];
        if ($senha == $confirmar) {
            $sql = "insert into tbcomercio(nome,email,contato,tel,senha)values('$nome','$email','$contato','$tel','$senha')";
            $query = mysqli_query($conn,$sql);
            header("location: ../view/tela_login.php");
        }
    }
    else {
        header("location: ../view/tela_cade_comercio.php");
        echo  "<script>alert('Email enviado com Sucesso!);</script>";
    }
?>