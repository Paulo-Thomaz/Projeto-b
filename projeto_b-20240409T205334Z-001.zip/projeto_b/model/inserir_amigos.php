<?php
    if($_POST["cxnome"] != ""){
        include_once "../factory/conexao.php";
        $nome = $_POST["cxnome"];
        $email = $_POST["cxemail"];
        $senha = $_POST["cxsenha"];
        $tel = $_POST["cxtel"];
        $datanasc = $_POST["cxdatanacs"];
        $confirmar = $_POST["cxconfirmar"];
        if ($senha == $confirmar) {
            $sql = "insert into tbamigos(nome,email,senha,tel,datanacs)values('$nome','$email','$senha','$tel','$datanacs')";
            $query = mysqli_query($conn,$sql);
            header("location:../view/tela_login.php");
        }
    }
    else {
        header("location: ../view/tela_cade_amigos.php");
        echo  "<script>alert('Email enviado com Sucesso!);</script>";
    }
?>