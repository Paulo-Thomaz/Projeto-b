<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        include_once "../factory/conexao.php";
        $email = $_POST["cxemail"];
        $senha = $_POST["cxsenha"];
        $consultar_u = "select *from tbusuario where email = '$email'";
        $consultar_a = "select *from tbamigos where email = '$email'";
        $consultar_c = "select *from tbcomercio where email = '$email'";

        $executar_u = mysqli_query($conn,$consultar_u);
        $executar_a = mysqli_query($conn,$consultar_a);
        $executar_c = mysqli_query($conn,$consultar_c);


        $linha1 = mysqli_fetch_array($executar_u);
        $linha2 = mysqli_fetch_array($executar_a);
        $linha3 = mysqli_fetch_array($executar_c);

        if ($linha1['senha'] == $senha || $linha2['senha'] == $senha || $linha3['senha'] == $senha) {
            header("location:../view/tela_menu.php");
        } else {
            header("location:../view/tela_login.php");
        }
    ?>


</body>
</html>d