<!DOCTYPE html>
<html lang="pt-bt">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/estilos.css">
    <title>Login</title>
</head>
<body>
    <header id="baner">
        <a href="tela_cade_comercio.php">cadastrar comercio</a>
        <a href="tela_cade_amigo.php">cadastrar amigos</a>
        <a href="tela_cade_user.php">cadastrar usuario</a>
        <br><br><br>
        <h1>Login</h1>
    </header>
    <section id="cxprincipal">
        <figure id="cxfigura"><img src="../img/user.png" alt="" class="user"></figure>
        <nav id="cxmenu">
            <form action="../model/processar_login.php" method="POST">
                <input type="text" name="cxemail" placeholder="Email" class="input_login"><br><br>
                <input type="text" name="cxsenha" placeholder="Senha" class="input_login"> <br><br>
                <input type="submit" value="login" class="input_login">
            </form>
        </nav>
    </section>
    <footer>
    Desenvolvido por &copy Paulo Thomaz Filho 3º info
    </footer>
</body>
</html>