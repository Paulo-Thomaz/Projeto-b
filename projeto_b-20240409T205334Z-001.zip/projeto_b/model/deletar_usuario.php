<?php
    
    include_once "../factory/conexao.php";

    $email = $_POST["cxemail_edit"];

    $deletar = "DELET FROM tbusuario WHERE email = '$email'";
    
    $executar = mysqli_query($conn,$deletar);
    
    if ($email !== "") {
        header("location: ../view/tela_login.php");
    }else {
        header("location: ../view/tela_edit_usuario.php");
    }
    
?>