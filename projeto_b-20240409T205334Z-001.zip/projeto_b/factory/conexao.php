<?php
    $server="localhost";
    $user="root";
    $senha="";
    $dbname="bdagendatb";
    $conn=mysqli_connect($server,$user,$senha,$dbname);
?>