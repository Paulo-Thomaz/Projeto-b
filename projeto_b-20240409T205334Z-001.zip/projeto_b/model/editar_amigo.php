<?php
        include_once "../factory/conexao.php";

        $email = $_POST["cxemail_edit"];

        $cxnome = $_POST["cxnome"];
        $cxemail = $_POST["cxemail"];
        $cxdatanacs = $_POST["cxdatanacs"];
        $cxtel = $_POST["cxtel"];
        $cxsenha = $_POST["cxsenha"];

        $alterar = "UPDATE tbamigos SET nome = '$cxnome', email = '$cxemail', datanacs = '$cxdatanacs', tel = '$cxtel', senha = '$cxsenha' where email = '$email'";

        $executar = mysqli_query($conn,$alterar);

        if ($email !== "") {
            header("location: ../view/tela_login.php");
        }else {
            header("location: ../view/tela_edit_amigo.php");
        }


    ?>